const usuario = {
    nombre: 'Diego',
    apellido: 'Salazar',
    edad: 21,
    direccion: {
      calle: 'Villa los corales',
      numero: 123,
      ciudad: 'Concepción',
      pais: 'Chile'
    },
    contactos: {
      telefono: '123456789',
      email: 'diegosalazar@example.com',
      redesSociales: {
        instagram: '@diego',
      }
    },
    intereses: ['Programación', 'Música', 'Ajedrez']
  };


const { nombre, apellido, direccion: { ciudad } } = usuario;

const [primerInteres] = usuario.intereses;

const { email } = usuario.contactos;
const { instagram } = usuario.contactos.redesSociales;

const { calle: calleUsuario, numero: numeroUsuario } = usuario.direccion;

console.log("Nombre:", nombre);
console.log("Apellido:", apellido);
console.log("Ciudad:", ciudad);
console.log("Primer interés:", primerInteres);
console.log("Email:", email);
console.log("Instagram:", instagram);
console.log("Calle del usuario:", calleUsuario);
console.log("Número del usuario:", numeroUsuario);