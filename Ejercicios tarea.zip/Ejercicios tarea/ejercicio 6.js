function convertirAMayusculas(cadena) {
    return cadena.toUpperCase();
}

function convertirAMinusculas(cadena) {
    return cadena.toLowerCase();
}

function restarNumeros(num1, num2) {
    return num1 - num2;
}

function dividirNumeros(num1, num2) {
    return num1 / num2;
}

function multiplicarNumeros(num1, num2) {
    return num1 * num2;
}

function obtenerLongitud(cadena) {
    return cadena.length;
}


console.log(convertirAMayusculas("hola mundo"));  
console.log(convertirAMinusculas("HOLA MUNDO"));  
console.log(restarNumeros(10, 5));               
console.log(dividirNumeros(20, 4));              
console.log(multiplicarNumeros(3, 4));            
console.log(obtenerLongitud("Hola"));         
