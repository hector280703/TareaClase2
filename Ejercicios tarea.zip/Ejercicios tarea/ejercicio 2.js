let numero1 = 20
let numero2 = 40

let suma = numero1 + numero2;
let resta = numero1 - numero2
let multiplicacion = numero1 * numero2;
let division = numero1 / numero2;
let modulo = numero2 % numero1;

console.log('Suma',suma);
console.log('Resta',resta);
console.log('Multiplicacion',multiplicacion);
console.log('Division',division);
console.log('Modulo',modulo);