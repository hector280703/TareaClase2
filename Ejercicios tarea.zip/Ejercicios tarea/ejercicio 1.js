let apellido = 'Diaz'
console.log(apellido);
console.log(typeof apellido);

let puedoconducir = true
console.log(puedoconducir);
console.log(typeof puedoconducir);