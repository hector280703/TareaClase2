const Persona ={
    nombre: 'Hector',
    edad: '21',
    genero: 'Masculino'
}

console.log(Persona);

const Caja = {
    cuadernos: 5,
    lapices: 2,
    papel: 10,
    fotografias: 4,
    Estado: true
}

console.log(Caja);
console.log(Caja.cuadernos);
console.log(Caja.lapices);
console.log(Caja.papel);
console.log(Caja.fotografias);