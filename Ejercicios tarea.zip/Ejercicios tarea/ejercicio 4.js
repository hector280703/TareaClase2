const numero1 = 10;
const numero2 = 20;
const numero3 = 30;


const mayor = Math.max(numero1, numero2, numero3);
console.log("El número mayor es:", mayor);

const menor = Math.min(numero1, numero2, numero3);
console.log("El número menor es:", menor);


console.log("numero1 es", (numero1 % 2 === 0 ? "par" : "impar"));
console.log("numero2 es", (numero2 % 2 === 0 ? "par" : "impar"));
console.log("numero3 es", (numero3 % 2 === 0 ? "par" : "impar"));

console.log("numero1", (numero1 % 5 === 0 ? "es" : "no es"), "múltiplo de 5");
console.log("numero2", (numero2 % 5 === 0 ? "es" : "no es"), "múltiplo de 5");
console.log("numero3", (numero3 % 5 === 0 ? "es" : "no es"), "múltiplo de 5");
