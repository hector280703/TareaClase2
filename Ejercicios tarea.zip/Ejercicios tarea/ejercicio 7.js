function sumarNumeros(array) {
    return array.reduce((acumulador, numero) => acumulador + numero, 0);
}

function calcularPromedio(array) {
    const suma = sumarNumeros(array);
    return suma / array.length;
}

function convertirStringsAMayusculas(array) {
    return array.map(cadena => cadena.toUpperCase());
}

function filtrarNumerosPares(array) {
    return array.filter(numero => numero % 2 === 0);
}


const numeros = [1, 2, 3, 4, 5, 6];
const cadenas = ["hola", "mundo", "javascript"];

console.log(sumarNumeros(numeros));                    
console.log(calcularPromedio(numeros));                
console.log(convertirStringsAMayusculas(cadenas));     
console.log(filtrarNumerosPares(numeros));             
